import numpy as np

rng = np.random.default_rng()
fitness_function = 'place_holder_func'
estimator = None
X_train = None
y_train = None
gene_pool = None
gnp_window = None
restrict_gnp = None
p_outlier = None
cv = 3
verbose = 0